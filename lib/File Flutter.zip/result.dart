import 'package:flutter/material.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:bmrcalc/widgets/custom_button.dart';
import 'package:bmrcalc/main.dart';
import 'package:percent_indicator/percent_indicator.dart';

// void main() {
//   runApp(const Result());
// }

// class Result extends StatelessWidget {
//   final String beratBadan, usia, tinggi;

//   const Result(
//       {super.key,
//       required this.beratBadan,
//       required this.usia,
//       required this.tinggi});

//   @override
//   Widget build(BuildContext context) {
//     return const Scaffold(
//       body: Second(
//         beratDua: 'Text',
//         usiaDua: 'Text',
//         tinggiDua:  'aa',
//       ),
//     );
//   }
// }

// class Second extends StatefulWidget {
//   final String beratDua, usiaDua, tinggiDua;
//   const Second(
//       {Key? key,
//       required this.beratDua,
//       required this.usiaDua,
//       required this.tinggiDua})
//       : super(key: key);

//    String getBeratDUa(){
//     return beratDua;
//   }
//   @override
//   State<Second> createState() => _SecondState();
// }

class Result extends StatelessWidget {
    const Result(
      {super.key,});

  @override
  Widget build(BuildContext context) {
   
    return Scaffold(
        body: Padding(
      padding: const EdgeInsets.only(top: 95, left: 24, right: 24),
      child: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              const Text(
                'Result',
                style: TextStyle(fontSize: 25),
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('JK', style: TextStyle(fontSize: 21)),
                  const SizedBox(
                    width: 20,
                  ),
                  const Text('Usia', style: TextStyle(fontSize: 21)),
                  const SizedBox(
                    width: 7,
                  ),
                  const Text('BB', style: TextStyle(fontSize: 21)),
                  const SizedBox(
                    width: 7,
                  ),
                  const Text('TB', style: TextStyle(fontSize: 21)),
                  // const SizedBox(width: 20,),
                  // const Text('Aktivitas', style: TextStyle(fontSize: 21)),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Pria', style: TextStyle(fontSize: 21)),
                  const SizedBox(
                    width: 8,
                  ),
                  const Text('70', style: TextStyle(fontSize: 21)),
                  const SizedBox(
                    width: 12,
                  ),
                  const Text('70', style: TextStyle(fontSize: 21)),
                  const SizedBox(
                    width: 12,
                  ),
                  const Text('170', style: TextStyle(fontSize: 21)),
                  // const SizedBox(width: 20,),
                  // const Text('Sangat Aktif Bergerak', style: TextStyle(fontSize: 21)),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              const Text('Aktivitas', style: TextStyle(fontSize: 21)),
              const SizedBox(
                height: 15,
              ),
              const Text('Sangat Aktif Bergerak',
                  style: TextStyle(fontSize: 21)),
              const SizedBox(
                height: 50,
              ),
              new CircularPercentIndicator(
                radius: 70.0,
                lineWidth: 10.0,
                percent: 0.7,
                center: new Text("70%"),
                progressColor: Colors.green,
              ),
              const SizedBox(
                height: 90,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                      child: ElevatedButton(
                    child: const Text('Kembali Ke Beranda'),
                    onPressed: () {
                      Navigator.pop(context);
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(builder: (context) => const Myapp()),
                      // );
                    },
                  )),
                ],
              )
            ],
          ),
        ),
      ),
    ));
  }
}
